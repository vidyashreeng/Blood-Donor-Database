package com.example.blooddoners;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.SQLClientInfoException;

public class MainActivity extends AppCompatActivity {
    EditText name,phone,bg,area,city;
    Button insert,search,view;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name=findViewById(R.id.name);
        phone=findViewById(R.id.phone);
        bg=findViewById(R.id.bg);
        area=findViewById(R.id.area);
        city=findViewById(R.id.city);

        insert=findViewById(R.id.btninsert);
        view=findViewById(R.id.btnview);
        search=findViewById(R.id.btnsearch);

        DB=new DBHelper(this);

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n=name.getText().toString();
                String p=phone.getText().toString();
                String b=bg.getText().toString();
                String a=area.getText().toString();
                String c=city.getText().toString();

                Boolean checkinsertdata=DB.insertdata(n,p,b,a,c);

                if (checkinsertdata==true)
                    Toast.makeText(MainActivity.this,"New Entry Instered",Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this,"Not Instered",Toast.LENGTH_SHORT).show();

            }
        });
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor res = DB.getdata();
                if (res.getCount() == 0) {
                    Toast.makeText(MainActivity.this, "Empty Table", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Name :" + res.getString(0) + "\n");
                    buffer.append("Phone :" + res.getString(1) + "\n");
                    buffer.append("Blood Group :" + res.getString(2) + "\n");
                    buffer.append("Area :" + res.getString(3) + "\n");
                    buffer.append("City :" + res.getString(4) + "\n");
                    buffer.append("-------------------------------------\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setCancelable(true);
                builder.setTitle("User Data");
                builder.setMessage(buffer.toString());
                builder.show();

            }

        });
        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s=new Intent(MainActivity.this,SearchPage.class);
                startActivity(s);
            }
        });
    }
}