package com.example.blooddoners;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class SearchPage extends Activity {
    EditText bgp, city;
    Button searchdata;
    DBHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_page);
        bgp=findViewById(R.id.bg1);
        city=findViewById(R.id.city1);

        searchdata=findViewById(R.id.btnsearch1);

        DB=new DBHelper(this);

        searchdata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String na = bgp.getText().toString();
                String nb=city.getText().toString();
                SQLiteDatabase simpledb=getApplicationContext().openOrCreateDatabase("bgdatabase.gb",MODE_PRIVATE,null);
                Cursor res=simpledb.rawQuery("select * from userdetails where bg='"+na+"' and city='"+nb+"'",null);
                if (res.getCount() == 0) {
                    Toast.makeText(SearchPage.this, "No data", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Name :" + res.getString(0) + "\n");
                    buffer.append("Phone :" + res.getString(1) + "\n");
                    buffer.append("Blood Group :" + res.getString(2) + "\n");
                    buffer.append("Area :" + res.getString(3) + "\n");
                    buffer.append("City :" + res.getString(4) + "\n");
                    buffer.append("-------------------------------------\n");

                }

                AlertDialog.Builder builder = new AlertDialog.Builder(SearchPage.this);
                builder.setCancelable(true);
                builder.setTitle("User Data");
                builder.setMessage(buffer.toString());
                builder.show();
            }
        });

    }
}